# Variables
name = "Brandon"
last_name = "Lile"
age = 36
price = 12.03
found = False

print(name + " " + last_name)
print (price)
print (str(age) + " years old")


# math operator
# same as JS
print(21 + 21)




# if statements
if (age < 100):
    print ("Dont worry you are young!")
    print("Still inside the if")
    print("Me too")
elif age ==100:
    print("Congrats on the century")
else:
    print("Sorry, you are getting old")

print("I'm outside the if")

#functions
def test():
    print("I'm a function")

# call a function
test()
test()
test()

